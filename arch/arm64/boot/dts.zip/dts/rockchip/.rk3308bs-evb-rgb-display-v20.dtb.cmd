cmd_arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb := clang -E -Wp,-MMD,arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.d.pre.tmp -nostdinc -I./scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.dts.tmp arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dts ; ./scripts/dtc/dtc -O dtb -o arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb -b 0 -iarch/arm64/boot/dts/rockchip/ -i./scripts/dtc/include-prefixes -Wno-interrupt_provider -@ -Wno-unit_address_vs_reg -Wno-unit_address_format -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg -Wno-unique_unit_address -Wno-pci_device_reg --symbols  -d arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.d.dtc.tmp arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.dts.tmp ; cat arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.d.pre.tmp arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.d.dtc.tmp > arch/arm64/boot/dts/rockchip/.rk3308bs-evb-rgb-display-v20.dtb.d

source_arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb := arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dts

deps_arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb := \
  arch/arm64/boot/dts/rockchip/rk3308bs-evb-amic-v11.dts \
  arch/arm64/boot/dts/rockchip/rk3308bs-evb-v11.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/input/input.h \
  scripts/dtc/include-prefixes/dt-bindings/input/linux-event-codes.h \
  arch/arm64/boot/dts/rockchip/rk3308b-evb-v10.dtsi \
  arch/arm64/boot/dts/rockchip/rk3308.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/clock/rk3308-cru.h \
  scripts/dtc/include-prefixes/dt-bindings/display/media-bus-format.h \
  scripts/dtc/include-prefixes/dt-bindings/display/../../uapi/linux/media-bus-format.h \
  scripts/dtc/include-prefixes/dt-bindings/gpio/gpio.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/arm-gic.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/irq.h \
  scripts/dtc/include-prefixes/dt-bindings/pinctrl/rockchip.h \
  scripts/dtc/include-prefixes/dt-bindings/soc/rockchip,boot-mode.h \
  scripts/dtc/include-prefixes/dt-bindings/suspend/rockchip-rk3308.h \
  scripts/dtc/include-prefixes/dt-bindings/thermal/thermal.h \
  arch/arm64/boot/dts/rockchip/rk3308bs-pinctrl.dtsi \

arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb: $(deps_arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb)

$(deps_arch/arm64/boot/dts/rockchip/rk3308bs-evb-rgb-display-v20.dtb):
