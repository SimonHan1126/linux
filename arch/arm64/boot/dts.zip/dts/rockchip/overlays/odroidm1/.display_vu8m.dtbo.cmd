cmd_arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo := mkdir -p arch/arm64/boot/dts/rockchip/overlays/odroidm1/ ; clang -E -Wp,-MMD,arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.d.pre.tmp -nostdinc -I./scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.dts.tmp arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dts ; ./scripts/dtc/dtc -@ -H epapr -O dtb -o arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo -b 0 -i arch/arm64/boot/dts/rockchip/overlays/odroidm1/ -Wno-interrupt_provider -@ -Wno-unit_address_vs_reg -Wno-unit_address_format -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg -Wno-unique_unit_address -Wno-pci_device_reg --symbols  -d arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.d.dtc.tmp arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.dts.tmp ; cat arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.d.pre.tmp arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.d.dtc.tmp > arch/arm64/boot/dts/rockchip/overlays/odroidm1/.display_vu8m.dtbo.d

source_arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo := arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dts

deps_arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo := \
  scripts/dtc/include-prefixes/dt-bindings/gpio/gpio.h \
  scripts/dtc/include-prefixes/dt-bindings/pinctrl/rockchip.h \
  scripts/dtc/include-prefixes/dt-bindings/display/drm_mipi_dsi.h \
  scripts/dtc/include-prefixes/dt-bindings/display/rockchip_vop.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/irq.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/arm-gic.h \

arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo: $(deps_arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo)

$(deps_arch/arm64/boot/dts/rockchip/overlays/odroidm1/display_vu8m.dtbo):
