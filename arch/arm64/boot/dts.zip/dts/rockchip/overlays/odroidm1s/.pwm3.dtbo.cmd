cmd_arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo := mkdir -p arch/arm64/boot/dts/rockchip/overlays/odroidm1s/ ; clang -E -Wp,-MMD,arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.d.pre.tmp -nostdinc -I./scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.dts.tmp arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dts ; ./scripts/dtc/dtc -@ -H epapr -O dtb -o arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo -b 0 -i arch/arm64/boot/dts/rockchip/overlays/odroidm1s/ -Wno-interrupt_provider -@ -Wno-unit_address_vs_reg -Wno-unit_address_format -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg -Wno-unique_unit_address -Wno-pci_device_reg --symbols  -d arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.d.dtc.tmp arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.dts.tmp ; cat arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.d.pre.tmp arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.d.dtc.tmp > arch/arm64/boot/dts/rockchip/overlays/odroidm1s/.pwm3.dtbo.d

source_arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo := arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dts

deps_arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo := \

arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo: $(deps_arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo)

$(deps_arch/arm64/boot/dts/rockchip/overlays/odroidm1s/pwm3.dtbo):
