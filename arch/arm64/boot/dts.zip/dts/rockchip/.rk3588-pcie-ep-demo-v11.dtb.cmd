cmd_arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb := clang -E -Wp,-MMD,arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.d.pre.tmp -nostdinc -I./scripts/dtc/include-prefixes -undef -D__DTS__ -x assembler-with-cpp -o arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.dts.tmp arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dts ; ./scripts/dtc/dtc -O dtb -o arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb -b 0 -iarch/arm64/boot/dts/rockchip/ -i./scripts/dtc/include-prefixes -Wno-interrupt_provider -@ -Wno-unit_address_vs_reg -Wno-unit_address_format -Wno-avoid_unnecessary_addr_size -Wno-alias_paths -Wno-graph_child_address -Wno-simple_bus_reg -Wno-unique_unit_address -Wno-pci_device_reg --symbols  -d arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.d.dtc.tmp arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.dts.tmp ; cat arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.d.pre.tmp arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.d.dtc.tmp > arch/arm64/boot/dts/rockchip/.rk3588-pcie-ep-demo-v11.dtb.d

source_arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb := arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dts

deps_arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb := \
  arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/usb/pd.h \
  arch/arm64/boot/dts/rockchip/rk3588.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/phy/phy-snps-pcie3.h \
  arch/arm64/boot/dts/rockchip/rk3588s.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/clock/rk3588-cru.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/arm-gic.h \
  scripts/dtc/include-prefixes/dt-bindings/interrupt-controller/irq.h \
  scripts/dtc/include-prefixes/dt-bindings/phy/phy.h \
  scripts/dtc/include-prefixes/dt-bindings/power/rk3588-power.h \
  scripts/dtc/include-prefixes/dt-bindings/soc/rockchip,boot-mode.h \
  scripts/dtc/include-prefixes/dt-bindings/soc/rockchip-system-status.h \
  scripts/dtc/include-prefixes/dt-bindings/suspend/rockchip-rk3588.h \
  scripts/dtc/include-prefixes/dt-bindings/thermal/thermal.h \
  arch/arm64/boot/dts/rockchip/rk3588s-pinctrl.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/pinctrl/rockchip.h \
  arch/arm64/boot/dts/rockchip/rk3588s-pinconf.dtsi \
  arch/arm64/boot/dts/rockchip/rk3588-vccio3-pinctrl.dtsi \
  arch/arm64/boot/dts/rockchip/rockchip-pinconf.dtsi \
  scripts/dtc/include-prefixes/dt-bindings/gpio/gpio.h \
  scripts/dtc/include-prefixes/dt-bindings/pwm/pwm.h \
  scripts/dtc/include-prefixes/dt-bindings/input/rk-input.h \
  scripts/dtc/include-prefixes/dt-bindings/display/drm_mipi_dsi.h \
  scripts/dtc/include-prefixes/dt-bindings/display/rockchip_vop.h \
  arch/arm64/boot/dts/rockchip/rk3588-rk806-single.dtsi \
  arch/arm64/boot/dts/rockchip/rk3588-android.dtsi \

arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb: $(deps_arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb)

$(deps_arch/arm64/boot/dts/rockchip/rk3588-pcie-ep-demo-v11.dtb):
